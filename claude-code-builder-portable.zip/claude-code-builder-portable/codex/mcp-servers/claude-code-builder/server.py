from __future__ import annotations

import json
import os
import hashlib
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any


SERVER_NAME = "claude-code-builder"
PROTOCOL_VERSION = "2024-11-05"
IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "node_modules",
    "dist",
    "build",
    ".next",
    ".vite",
}
DEFAULT_AGENTS = {
    "codex_builder": {
        "description": "Bounded implementation worker invoked by Codex",
        "prompt": (
            "You are a Claude Code implementation subagent invoked by Codex. "
            "You are not alone in this codebase. Do not revert edits made by others. "
            "Stay inside the owned scope unless necessary. Prefer existing project patterns. "
            "Finish with RESULT_STATUS, changed files, commands run, and blockers."
        ),
    },
    "codex_explorer": {
        "description": "Read-only exploration helper for a Claude Code worker",
        "prompt": (
            "You are a read-only exploration subagent. Inspect code and explain findings. "
            "Do not modify files."
        ),
    },
    "codex_reviewer": {
        "description": "Read-only review helper for a Claude Code worker",
        "prompt": (
            "You are a read-only code review subagent. Review changes for bugs, regressions, "
            "scope violations, and missing tests. Do not modify files."
        ),
    },
}
DEFAULT_ALLOWED_TOOLS = [
    "Bash(npm test)",
    "Bash(npm run test)",
    "Bash(node *)",
    "Bash(python -m pytest *)",
    "Bash(pytest *)",
    "Bash(pytest)",
    "Bash(python -m unittest *)",
    "Bash(git status *)",
    "Bash(git diff *)",
    "Bash(git diff)",
]

if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def _claude_command() -> str:
    if os.name == "nt":
        return shutil.which("claude.cmd") or shutil.which("claude") or "claude.cmd"
    return shutil.which("claude") or "claude"


def _text_result(text: str, is_error: bool = False) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": text}], "isError": is_error}


def _resolve_repo(repo: str) -> Path:
    repo_path = Path(repo).expanduser().resolve()
    if not repo_path.is_dir():
        raise ValueError(f"Invalid repo path: {repo}")
    return repo_path


def _normalize_owned_paths(repo_path: Path, owned_paths: list[Any]) -> list[str]:
    if not owned_paths:
        raise ValueError("owned_paths is required")
    normalized: list[str] = []
    for raw in owned_paths:
        item = str(raw).strip()
        if not item:
            continue
        path = (repo_path / item).resolve() if not Path(item).is_absolute() else Path(item).resolve()
        try:
            path.relative_to(repo_path)
        except ValueError as exc:
            raise ValueError(f"owned path is outside repo: {item}") from exc
        normalized.append(path.relative_to(repo_path).as_posix())
    if not normalized:
        raise ValueError("owned_paths is required")
    return normalized


def _paths_overlap(a: str, b: str) -> bool:
    if os.name == "nt":
        a = a.casefold()
        b = b.casefold()
    pa = Path(a)
    pb = Path(b)
    return pa == pb or pa in pb.parents or pb in pa.parents


def _is_under_owned_scope(path: str, owned_paths: list[str]) -> bool:
    candidate = path.casefold() if os.name == "nt" else path
    for owned in owned_paths:
        scope = owned.casefold() if os.name == "nt" else owned
        if candidate == scope or candidate.startswith(scope.rstrip("/") + "/"):
            return True
    return False


def _should_skip(path: Path, repo_path: Path) -> bool:
    try:
        relative = path.relative_to(repo_path)
    except ValueError:
        return True
    return any(part in IGNORED_DIRS for part in relative.parts)


def _file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _snapshot_files(repo_path: Path) -> dict[str, str]:
    snapshot: dict[str, str] = {}
    for path in repo_path.rglob("*"):
        if _should_skip(path, repo_path) or not path.is_file():
            continue
        relative = path.relative_to(repo_path).as_posix()
        try:
            stat = path.stat()
            snapshot[relative] = f"{stat.st_size}:{stat.st_mtime_ns}:{_file_digest(path)}"
        except OSError:
            continue
    return snapshot


def _changed_paths(before: dict[str, str], after: dict[str, str]) -> list[str]:
    paths = set(before) | set(after)
    return sorted(path for path in paths if before.get(path) != after.get(path))


def _extract_report_status(text: str) -> str:
    for line in text.splitlines():
        normalized = line.strip().lower().replace("*", "").replace("`", "").strip("_- ")
        if "result_status:" in normalized:
            value = normalized.split("result_status:", 1)[1].strip().strip("*`_- ")
            if value in {"success", "blocked", "failed"}:
                return value
    return "missing"


def _validate_disjoint(tasks: list[dict[str, Any]], repo_path: Path) -> None:
    seen: list[tuple[str, str]] = []
    for task in tasks:
        task_name = str(task.get("task_name") or "task")
        owned = _normalize_owned_paths(repo_path, task.get("owned_paths") or [])
        for path in owned:
            for other_name, other_path in seen:
                if _paths_overlap(path, other_path):
                    raise ValueError(
                        f"parallel tasks have overlapping ownership: {task_name}:{path} and {other_name}:{other_path}"
                    )
            seen.append((task_name, path))


def _builder_prompt(
    repo_path: Path,
    task_name: str,
    task: str,
    owned_paths: list[str],
    verification: str,
    extra_context: str,
) -> str:
    owned = "\n".join(f"- {path}" for path in owned_paths)
    verify = verification.strip() or "Run the most relevant lightweight checks if practical."
    context = extra_context.strip()
    context_block = f"\nAdditional context:\n{context}\n" if context else ""
    return f"""You are a Claude Code implementation subagent invoked by Codex.

You are not alone in this codebase. Other agents or the user may be editing nearby files.
Do not revert edits made by others. Do not perform broad cleanup outside your task.
Adapt your implementation to the current codebase state.

Project root:
{repo_path}

Task name:
{task_name}

Task:
{task}

Owned scope:
{owned}

Rules:
- You may edit files in the owned scope.
- Do not edit outside the owned scope unless the task is impossible without it.
- If you must edit outside the owned scope, keep it minimal and explain why.
- Prefer the repository's existing patterns and tests.
- Keep changes focused on the assigned task.
- Do not commit changes.
- You may use Claude's Agent/Task tool for internal help when useful.
- Use codex_explorer only for read-only investigation.
- Use codex_reviewer only for read-only review after implementation.
- Do not let internal subagents edit files or expand the owned scope.

Verification:
{verify}

Verification rules:
- If a verification command is provided, try to run it unless it is clearly destructive.
- Do not say a command was blocked unless the tool actually returns a permission/blocking error.
- If verification fails or is blocked, include the exact command and error/output.
- If verification is not run, RESULT_STATUS must be blocked unless the task explicitly says tests are unnecessary.
{context_block}
Final response:
- RESULT_STATUS: success | blocked | failed
- Changed files
- Commands/tests run
- Blockers or follow-up needed
"""


def _run_claude_task(
    repo: str,
    task: str,
    owned_paths: list[Any],
    task_name: str = "claude-builder-task",
    verification: str = "",
    extra_context: str = "",
    effort: str = "high",
    permission_mode: str = "acceptEdits",
    model: str = "",
    timeout_seconds: int = 3600,
    validate_scope: bool = True,
    allowed_tools: list[Any] | None = None,
) -> dict[str, Any]:
    repo_path = _resolve_repo(repo)
    normalized_owned = _normalize_owned_paths(repo_path, owned_paths)
    prompt = _builder_prompt(repo_path, task_name, task, normalized_owned, verification, extra_context)
    timeout_seconds = max(1, int(timeout_seconds))

    command = [
        _claude_command(),
        "-p",
        "--permission-mode",
        permission_mode,
        "--effort",
        effort,
        "--output-format",
        "text",
        "--agents",
        json.dumps(DEFAULT_AGENTS, ensure_ascii=False, separators=(",", ":")),
        "--agent",
        "codex_builder",
    ]
    effective_allowed_tools = [str(item) for item in (allowed_tools or DEFAULT_ALLOWED_TOOLS) if str(item).strip()]
    if effective_allowed_tools:
        command.append("--allowedTools")
        command.extend(effective_allowed_tools)
    if model.strip():
        command.extend(["--model", model.strip()])
    command.extend(["--add-dir", str(repo_path)])
    command_for_record = [
        "<claude>",
        "-p",
        "--permission-mode",
        permission_mode,
        "--effort",
        effort,
        "--output-format",
        "text",
        "--agents",
        "<codex_builder/codex_explorer/codex_reviewer>",
        "--agent",
        "codex_builder",
        "--allowedTools",
        "<verification allowlist>",
        "<prompt via stdin>",
    ]
    if model.strip():
        command_for_record.extend(["--model", model.strip()])
    command_for_record.extend(["--add-dir", str(repo_path)])

    before = _snapshot_files(repo_path) if validate_scope else {}
    try:
        completed = subprocess.run(
            command,
            input=prompt,
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
        after = _snapshot_files(repo_path) if validate_scope else {}
        changed = _changed_paths(before, after) if validate_scope else []
        outside_owned = [path for path in changed if not _is_under_owned_scope(path, normalized_owned)] if validate_scope else []
        report_status = _extract_report_status(f"{completed.stdout}\n{completed.stderr}")
        success = completed.returncode == 0 and not outside_owned and report_status == "success"
        return {
            "task_name": task_name,
            "repo": str(repo_path),
            "owned_paths": normalized_owned,
            "command": command_for_record,
            "exit_code": completed.returncode,
            "success": success,
            "report_status": report_status,
            "changed_paths": changed,
            "outside_owned_changes": outside_owned,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
        }
    except Exception as exc:
        after = _snapshot_files(repo_path) if validate_scope else {}
        changed = _changed_paths(before, after) if validate_scope else []
        outside_owned = [path for path in changed if not _is_under_owned_scope(path, normalized_owned)] if validate_scope else []
        return {
            "task_name": task_name,
            "repo": str(repo_path),
            "owned_paths": normalized_owned,
            "command": command_for_record,
            "exit_code": -1,
            "success": False,
            "report_status": "failed",
            "changed_paths": changed,
            "outside_owned_changes": outside_owned,
            "stdout": "",
            "stderr": str(exc),
        }


def _tool_schemas() -> list[dict[str, Any]]:
    task_props = {
        "task_name": {"type": "string", "description": "Short stable name for this worker task."},
        "task": {"type": "string", "description": "Bounded implementation request for Claude Code."},
        "owned_paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Files or directories this worker owns, relative to repo.",
        },
        "verification": {"type": "string", "description": "Suggested tests/checks to run.", "default": ""},
        "extra_context": {"type": "string", "description": "Additional task-local context.", "default": ""},
    }
    return [
        {
            "name": "claude_builder_doctor",
            "description": "Check Claude Code CLI availability.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        },
        {
            "name": "claude_builder_run",
            "description": "Run one bounded Claude Code implementation worker.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "repo": {"type": "string", "description": "Project root path."},
                    **task_props,
                    "effort": {
                        "type": "string",
                        "enum": ["low", "medium", "high", "xhigh", "max"],
                        "default": "high",
                    },
                    "permission_mode": {
                        "type": "string",
                        "enum": ["acceptEdits", "auto", "default", "dontAsk", "plan", "bypassPermissions"],
                        "default": "acceptEdits",
                    },
                    "model": {"type": "string", "description": "Optional Claude model alias/name.", "default": ""},
                    "allowed_tools": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional Claude allowedTools entries. Defaults allow common test/status commands.",
                    },
                    "timeout_seconds": {"type": "integer", "default": 3600, "minimum": 1},
                },
                "required": ["repo", "task", "owned_paths"],
                "additionalProperties": False,
            },
        },
        {
            "name": "claude_builder_parallel",
            "description": "Run independent Claude Code implementation workers concurrently. Each task must have disjoint owned_paths.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "repo": {"type": "string", "description": "Project root path shared by all workers."},
                    "tasks": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": task_props,
                            "required": ["task", "owned_paths"],
                            "additionalProperties": False,
                        },
                    },
                    "effort": {
                        "type": "string",
                        "enum": ["low", "medium", "high", "xhigh", "max"],
                        "default": "high",
                    },
                    "permission_mode": {
                        "type": "string",
                        "enum": ["acceptEdits", "auto", "default", "dontAsk", "plan", "bypassPermissions"],
                        "default": "acceptEdits",
                    },
                    "model": {"type": "string", "default": ""},
                    "allowed_tools": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional Claude allowedTools entries shared by all workers.",
                    },
                    "timeout_seconds": {"type": "integer", "default": 3600, "minimum": 1},
                    "max_workers": {"type": "integer", "default": 3, "minimum": 1},
                },
                "required": ["repo", "tasks"],
                "additionalProperties": False,
            },
        },
    ]


def _call_tool(name: str, arguments: dict[str, Any] | None) -> dict[str, Any]:
    args = arguments or {}
    try:
        if name == "claude_builder_doctor":
            command = [_claude_command(), "--version"]
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=60,
                check=False,
            )
            return _text_result(json.dumps({
                "command": command,
                "exit_code": completed.returncode,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            }, ensure_ascii=False, indent=2), completed.returncode != 0)

        if name == "claude_builder_run":
            result = _run_claude_task(
                repo=str(args.get("repo", "")),
                task=str(args.get("task", "")),
                owned_paths=args.get("owned_paths") or [],
                task_name=str(args.get("task_name") or "claude-builder-task"),
                verification=str(args.get("verification") or ""),
                extra_context=str(args.get("extra_context") or ""),
                effort=str(args.get("effort") or "high"),
                permission_mode=str(args.get("permission_mode") or "acceptEdits"),
                model=str(args.get("model") or ""),
                timeout_seconds=int(args.get("timeout_seconds") or 3600),
                allowed_tools=args.get("allowed_tools"),
            )
            return _text_result(json.dumps(result, ensure_ascii=False, indent=2), not result["success"])

        if name == "claude_builder_parallel":
            repo = str(args.get("repo", ""))
            repo_path = _resolve_repo(repo)
            tasks = args.get("tasks") or []
            if not isinstance(tasks, list) or not tasks:
                raise ValueError("tasks must be a non-empty array")
            _validate_disjoint(tasks, repo_path)
            aggregate_owned: list[str] = []
            for task in tasks:
                aggregate_owned.extend(_normalize_owned_paths(repo_path, task.get("owned_paths") or []))
            before = _snapshot_files(repo_path)
            max_workers = max(1, min(int(args.get("max_workers") or 3), len(tasks)))
            results: list[dict[str, Any]] = []
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futures = []
                for index, task in enumerate(tasks, start=1):
                    task_name = str(task.get("task_name") or f"claude-builder-task-{index}")
                    futures.append(pool.submit(
                        _run_claude_task,
                        repo,
                        str(task.get("task", "")),
                        task.get("owned_paths") or [],
                        task_name,
                        str(task.get("verification") or ""),
                        str(task.get("extra_context") or ""),
                        str(args.get("effort") or "high"),
                        str(args.get("permission_mode") or "acceptEdits"),
                        str(args.get("model") or ""),
                        int(args.get("timeout_seconds") or 3600),
                        False,
                        args.get("allowed_tools"),
                    ))
                for future in as_completed(futures):
                    try:
                        results.append(future.result())
                    except Exception as exc:
                        results.append({
                            "task_name": "unknown",
                            "repo": str(repo_path),
                            "owned_paths": [],
                            "command": [],
                            "exit_code": -1,
                            "success": False,
                            "report_status": "failed",
                            "changed_paths": [],
                            "outside_owned_changes": [],
                            "stdout": "",
                            "stderr": str(exc),
                        })
            after = _snapshot_files(repo_path)
            aggregate_changed = _changed_paths(before, after)
            aggregate_outside = [path for path in aggregate_changed if not _is_under_owned_scope(path, aggregate_owned)]
            payload = {
                "repo": str(repo_path),
                "success": all(bool(item.get("success")) for item in results) and not aggregate_outside,
                "aggregate_changed_paths": aggregate_changed,
                "aggregate_outside_owned_changes": aggregate_outside,
                "results": results,
            }
            return _text_result(json.dumps(payload, ensure_ascii=False, indent=2), not payload["success"])

        return _text_result(f"Unknown tool: {name}", True)
    except Exception as exc:
        return _text_result(str(exc), True)


def _response(message_id: Any, result: Any = None, error: dict[str, Any] | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {"jsonrpc": "2.0", "id": message_id}
    if error is not None:
        payload["error"] = error
    else:
        payload["result"] = result
    return payload


def _handle(message: dict[str, Any]) -> dict[str, Any] | None:
    method = message.get("method")
    message_id = message.get("id")
    params = message.get("params") or {}
    if message_id is None:
        return None
    if method == "initialize":
        return _response(message_id, {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": SERVER_NAME, "version": "0.1.0"},
        })
    if method == "tools/list":
        return _response(message_id, {"tools": _tool_schemas()})
    if method == "tools/call":
        return _response(message_id, _call_tool(str(params.get("name")), params.get("arguments") or {}))
    return _response(message_id, error={"code": -32601, "message": f"Method not found: {method}"})


def main() -> None:
    for line in sys.stdin:
        line = line.strip().lstrip("\ufeff")
        if not line:
            continue
        try:
            response = _handle(json.loads(line))
        except Exception as exc:
            response = _response(None, error={"code": -32603, "message": str(exc)})
        if response is not None:
            sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
