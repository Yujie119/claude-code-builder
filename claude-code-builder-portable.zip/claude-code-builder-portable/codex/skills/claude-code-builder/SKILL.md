---
name: claude-code-builder
description: Delegate bounded implementation work to the local Claude Code CLI as an external coding subagent. Use when the user explicitly asks for Claude, Claude Code, an external subagent, or parallel agents to write code, implement features, fix bugs, refactor files, or perform coding work that can be split into clear ownership scopes.
---

# Claude Code Builder

Use this skill when Claude Code should act like an external implementation worker while Codex remains the primary controller.

## Policy

- Codex owns planning, task decomposition, integration, conflict resolution, and final verification.
- Use Claude Code for bounded implementation tasks, especially when the user explicitly asks for a subagent to write code.
- Give each Claude worker a concrete task, a project root, and an owned file/path scope.
- For parallel Claude workers, use disjoint ownership scopes. Do not assign overlapping files.
- Tell Claude it is not alone in the codebase, must not revert edits made by others, and must adapt to existing changes.
- Ask Claude to finish with changed file paths, tests/commands run, and blockers.
- Review Claude's changes before integrating or finalizing.
- For parallel tasks, the MCP server rejects overlapping owned paths and checks the aggregate diff stays inside the union of owned paths.

## MCP Tools

The `claude-code-builder` MCP server exposes:

- `claude_builder_run`: run one bounded Claude Code implementation task.
- `claude_builder_parallel`: run several independent Claude Code implementation tasks concurrently.
- `claude_builder_doctor`: check Claude Code CLI availability.

Default tool behavior:

- `permission_mode`: `acceptEdits`
- `effort`: `high`
- `output_format`: `text`
- direct Claude Code CLI invocation
- injects Claude agents: `codex_builder`, `codex_explorer`, `codex_reviewer`
- runs the current Claude session as `--agent codex_builder`
- passes a default `--allowedTools` allowlist for common verification commands, including `npm test`, `npm run test`, `node *`, `python -m pytest *`, `pytest *`, and read-only `git status/diff`

Use `effort=xhigh` or `effort=max` only for difficult implementation tasks.
Claude may use its own Agent/Task tool internally for read-only exploration or review, but Codex still owns decomposition and final integration.
If a verification command is provided, Claude should try to run it and report exact failures. Codex must still run final verification.

## Shell Equivalent

For one task:

```powershell
@'
<bounded implementation prompt>
'@ | claude -p `
  --permission-mode acceptEdits `
  --effort high `
  --output-format text `
  --agents '<json defining codex_builder/codex_explorer/codex_reviewer>' `
  --agent codex_builder `
  --add-dir "<project-root>"
```

## Prompt Shape

Include:

- Task objective.
- Owned files or paths.
- Explicit non-ownership boundaries.
- Expected verification commands.
- Instruction to avoid reverting unrelated/user changes.
- Final report format: changed files, tests run, blockers.
- Whether Claude may use its internal read-only explorer/reviewer agents.

Example:

```text
You are a Claude Code implementation subagent invoked by Codex.
You are not alone in this codebase. Do not revert edits made by others.

Project root: <path>
Task: implement <feature/fix>.
Owned scope: <paths>.
Do not edit outside the owned scope unless necessary; if necessary, explain why.
Run relevant tests if practical.
Final response: changed files, commands run, blockers.
```
